import { useState, useRef, useEffect, useContext } from "react";
import { Navigate } from "react-router-dom";
import axios from "axios";
import AuthContext from "../context/UsrDetailProvider";

const Login = () => {
  const [userName, setUserName] = useState();
  const [pwd, setPwd] = useState();
  const [errMsg, setErrMsg] = useState();
  const [isSuccess, setIsSuccess] = useState(false);

  const { setAuth } = useContext(AuthContext);

  const userRef = useRef();
  const errRef = useRef();
  useEffect(() => {
    userRef.current.focus();
  }, []);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = "http://localhost:8000/users";
    try {
      let response = await axios.get(`${url}?username=${userName}`);
      const userData = response.data[0];
      const { username, password } = userData;
      if (username) {
        if (pwd !== password) {
          setErrMsg("Wrong Password");
        } else {
          setAuth(userData);
          setIsSuccess(true);
          setUserName('');
          setPwd('');
        }
      }
    } catch (err) {
      if (!err?.response) {
        console.log(err.response);
        setErrMsg("User Does Not Exist");
      } else {
        setErrMsg("Login Failed");
      }
    }
  };
  const hadleChange = (e) => {
    const { id, value } = e.target;
    if (id === "userName") {
      setUserName(value);
    } else if (id === "password") {
      setPwd(value);
    }
  };
  console.log();
  return (
    <>
      {isSuccess ? (
        <>
          <Navigate to="/menu" />
        </>
      ) : (
        <div className="login-page">
          <section className="login-section">
            <p ref={errRef} className={errMsg ? "errmsg" : "offscreen"}>
              {errMsg}
            </p>
            <h1>Sign In</h1>
            <form className="login-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="userName">User Name</label>
                <input
                  type="text"
                  id="userName"
                  placeholder="User Name"
                  className="form-control"
                  onChange={hadleChange}
                  ref={userRef}
                  value={userName}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  id="password"
                  placeholder="Password"
                  className="form-control"
                  onChange={hadleChange}
                  value={pwd}
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Sign In
              </button>
            </form>
          </section>
        </div>
      )}
    </>
  );
};

export default Login;
