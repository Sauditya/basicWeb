import { useState, useEffect,useContext } from "react";
import axios from "axios";
import Dish from "./Dish";
import Header from "./Header";
import RankingModal from "./RankingModal";
// import AuthContext from "../context/UsrDetailProvider";
import DishListContext from "../context/DishListProvider";
const MenuPage = () => {
  // const [dishList, setDishList] = useState([]);
  const [slctDsh,setSlctDsh] = useState({})
  const [showModal, setShowModal] = useState(false);
  // const { auth } = useContext(AuthContext);
  const { dishList,setDishList } = useContext(DishListContext);
  useEffect(() => {
    let url = `http://localhost:8000/dishes`;
    const fetchApi = async (url) => {
      let response = await axios.get(url);
      let list = response.data;
      let sortedList = list.sort((a,b)=>{
        let frstPoint = a.point ? a.point : 0;
        let secPoint = b.point ? b.point : 0;
        return secPoint - frstPoint;
      })
      setDishList(sortedList);
    };
    fetchApi(url);
  }, []);
  const showModalPage = (obj)=>{
    setSlctDsh(obj);
    setShowModal(true);
  }
  const modalClose = ()=>{
    setShowModal(false);
  }
  return (<>{showModal && <RankingModal modalhandler={modalClose} dish={slctDsh}/>}
    <>
      <Header />
      <div className="d-flex flex-column px-5">
        {dishList.map((dish) => {
          const { id } = dish;
          return (
            <Dish key={id} dish={dish} modalView={showModalPage}/>
          );
        })}
      </div>
    </>
    </>
  );
};

export default MenuPage;
