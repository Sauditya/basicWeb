import { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import AuthContext from "../context/UsrDetailProvider";

const Dish = ({ dish, modalView }) => {
  const { dishName, image, description } = dish;
  const [isDesktop, setDesktop] = useState(window.innerWidth >= 576);
  const [cls, setCls] = useState("");
  const [showModal, setShowModal] = useState(false);
  const { auth } = useContext(AuthContext);

  const nav = useNavigate();

  const updateMedia = () => {
    setDesktop(window.innerWidth >= 576);
  };
  useEffect(() => {
    window.addEventListener("resize", updateMedia);
    return () => window.removeEventListener("resize", updateMedia);
  });

  useEffect(() => {
    if (auth.choice) {
      const { frst, scnd, thrd } = auth.choice;
      if (frst && frst.id === dish.id) {
        setCls("frst");
      } else if (scnd && scnd.id === dish.id) {
        setCls("scnd");
      } else if (thrd && thrd.id === dish.id) {
        setCls("thrd");
      }
    }
  }, []);

  const handleClick = () => {
    if (auth.id) {
      modalView(dish);
    } else {
      nav("/");
    }
  };

  return (
    <section className="dish-section" onClick={handleClick}>
      {isDesktop ? (
        <div
          className={`card mb-3 ${cls} card-big`}
          onMouseEnter={() => setShowModal(true)}
          onMouseLeave={() => setShowModal(false)}
          style={{ height: "12rem" }}
        >
          {showModal && (
            <div className="card-modal">
              <h5 className="card-title">{dishName}</h5>
              <p className="card-text">{description}</p>
            </div>
          )}
          <div className="row no-gutters">
            <div className="col-md-5 col-sm-6 big-img">
              <img src={image} className="card-img" alt="..." />
            </div>
            <div className="col-md-7 col-sm-6 mid-div">
              <div className="card-body">
                <h5 className="card-title">{dishName}</h5>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div
          className={`card text-white ${cls} card-small`}
          style={{ height: "12rem" }}
        >
          <img className="card-img-top" src={image} alt={dishName} />
          <div className="card-img-overlay">
            <h5 className="card-title">{dishName}</h5>
            <p className="card-text">{description}</p>
          </div>
        </div>
      )}
    </section>
  );
};

export default Dish;
