import { useState, useContext, useEffect } from "react";
import axios from "axios";
import AuthContext from "../context/UsrDetailProvider";
import DishListContext from "../context/DishListProvider";

const RankingModal = (props) => {
  
  const {auth,setAuth} = useContext(AuthContext);
  const [dsh, setDsh] = useState(props.dish);
  const [rank, setRank] = useState(1);
  const [isSelected, setIsSelected] = useState(false);

  
  const { dishList, setDishList } = useContext(DishListContext);

  useEffect(()=>{
    if(auth.choice){
      const {scnd,thrd} = auth.choice;
     if (scnd && scnd.id === dsh.id) {
        setRank(2)
      } else if(thrd && thrd.id === dsh.id){
        setRank(3);
      }
    }
  },[])

  const handleConfirm = () => {
    let point = dsh.point ? dsh.point : 0;
    const user = { ...auth };
    if (!user.choice) {
      user.choice = {};
    } else {
      let { frst, scnd, thrd } = user.choice;
      if (frst && frst.id === dsh.id) {
        point -= 30;
        delete user.choice.frst;
      } else if (scnd && scnd.id === dsh.id) {
        point -= 20;
        delete user.choice.scnd;
      } else if (thrd && thrd.id === dsh.id) {
        point -= 10;
        delete user.choice.thrd;
      }
    }
    const { choice } = user;
    const dishlst = [...dishList];
    const nwChoice = (({id,dishName})=>({id,dishName}))(dsh);
    if (rank === 1) {
      if(choice.frst){
        const prevDishIndex = dishlst.findIndex((dish)=>dish.id === choice.frst.id)
        dishlst[prevDishIndex].point -= 30;
      }
      choice.frst = nwChoice;
      point += 30
    } else if (rank === 2) {
      if(choice.scnd){
        const prevDishIndex = dishlst.findIndex((dish)=>dish.id === choice.scnd.id)
        console.log("prev index "+prevDishIndex);
        dishlst[prevDishIndex].point -= 20;
      }
      choice.scnd = nwChoice;
      point += 20
    } else {
      if(choice.thrd){
        const prevDishIndex = dishlst.findIndex((dish)=>dish.id === choice.thrd.id)
        dishlst[prevDishIndex].point -= 10;
      }
      choice.thrd = nwChoice;
      point += 10
    }
    const dishIndex = dishlst.findIndex((ele)=>ele.id === dsh.id);
    dishlst[dishIndex].point = point;
    let sortedList = dishList.sort((a,b)=>{
      let frstPoint = a.point ? a.point : 0;
      let secPoint = b.point ? b.point : 0;
      return frstPoint - secPoint
    })
    setDsh({...dsh,point});
    setAuth(user);
    updateUser(user);
    updateDish(dsh);
    setDishList(sortedList);
    props.modalhandler();
  };

  const updateUser = async (obj) => {
    const url = "http://localhost:8000/users";
    try {
      const res = await axios.put(`${url}/${obj.id}`, obj);
      console.log(res.status);
    } catch (err) {
      console.log(err.response);
    }
  };
  const updateDish = async (obj) => {
    const url = "http://localhost:8000/dishes";
    try {
      const res = await axios.put(`${url}/${obj.id}`, obj);
      console.log(res.status);
    } catch (err) {
      console.log(err.response);
    }
  };

  const chngRank = (e) => {
    setRank(Number(e.target.value));
    setIsSelected(true);
  };
  
  const handleClose = (e)=>{
    props.modalhandler();
  }

  return (
    <div className="modal" onClick={handleClose}>
      <div className="close-btn" onClick={handleClose}>X</div>
      <section className="ranking-section" onClick={(e)=>e.stopPropagation()}>
        {isSelected && (
          <p className="msg">You Have Chose this as rank {rank}</p>
        )}
        <h1>{dsh.dishName}</h1>
        <h3>Choose Your Rank</h3>
        <section className="selection-section">
          {(function (arr, count) {
            console.log("rank from jsx "+rank);
            for (let i = 1; i <= count; i++) {
              let checkElement = (
                <div key={i} className="form-check form-check-inline">
                  <input
                    onChange={chngRank}
                    type="radio"
                    name="ranks"
                    id="rank1"
                    value={i}
                    checked={i === rank}
                    defaultChecked={i === rank}
                  />
                  <label htmlFor={`rank${i}`}>{i}</label>
                </div>
              );
              arr.push(checkElement);
            }
            return arr;
          })([], 3)}
        </section>
        <button onClick={handleConfirm}>Confirm</button>
      </section>
    </div>
  );
};

export default RankingModal;
