import AuthContext from "../context/UsrDetailProvider";
import {useNavigate} from "react-router-dom";
import { useContext } from "react";

const Header =()=>{
    const { auth,setAuth } = useContext(AuthContext);
    const nav = useNavigate();
    const handleClick = ()=>{
        if(auth.id){
            setAuth({});
        }
        nav('/');
    }
    return (<header>
        <button className="btn" onClick={handleClick}>{auth.id ? 'Logout':'Login'}</button>
    </header>)
}

export default Header;