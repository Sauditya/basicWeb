import { createContext, useState } from "react";

const DishListContext = createContext({});

export const DishlistProvider = ({ children }) => {
  const [dishList, setDishList] = useState([]);

  return (
    <DishListContext.Provider value={{ dishList, setDishList }}>
      {children}
    </DishListContext.Provider>
  );
};

export default DishListContext;
